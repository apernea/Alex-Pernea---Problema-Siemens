package org.example.problema;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class GeolocationUtil {
    private static final String API_URL = "https://ipinfo.io/79.113.38.12?token=6d45ccde687cd8";

    public static List<Double> getCoordinatesFromIp() {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(API_URL);
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    String result = EntityUtils.toString(entity);
                    JSONObject jsonObject = new JSONObject(result);
                    String loc = jsonObject.getString("loc");
                    String[] coordinates = loc.split(",");
                    double latitude = Double.parseDouble(coordinates[0]);
                    double longitude = Double.parseDouble(coordinates[1]);
                    List<Double> coordinateList = new ArrayList<>();
                    coordinateList.add(latitude);
                    coordinateList.add(longitude);
                    return coordinateList;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}