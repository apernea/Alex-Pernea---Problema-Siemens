package org.example.problema;

import java.io.IOException;
import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Main {
    private static final Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        List<Hotel> hotels;

        try {
            hotels = JsonUtils.loadHotels("file://$PROJECT_DIR$/Problema/src/main/webapp/WEB-INF/hotels.json");
        } catch (IOException e) {
            System.err.println("Error loading file: " + e.getMessage());
            return;
        }

        HotelReservationSystem reservationSystem = new HotelReservationSystem(hotels);

        System.out.println("Bine ati venit la Hotel Reservation!");

        System.out.print("Ce buget aveti pentru cazare? ");
        double userBudget = scan.nextDouble();

        System.out.print("Va rugam introduceti raza in kilometri in care ati dori sa cautati un hotel (<=1): ");
        double range = scan.nextDouble();

        List<Hotel> availableHotels = reservationSystem.getHotelsInRange(range);
        if (availableHotels.isEmpty()) {
            System.out.println("Nu exista hoteluri disponibile in raza de " + range + " km.");
            return;
        }

        System.out.println("\nHotelurile disponibile in raza de " + range + " km sunt: ");
        displayHotels(availableHotels);

        System.out.print("\nSelectati hotelul la care ati dori sa va cazati: ");
        int indexHotel = scan.nextInt();
        Hotel chosenHotel = availableHotels.get(indexHotel - 1);

        List<Room> availableRooms = chosenHotel.getTypesOfRooms();
        int nrOfRooms = 0;
        for (Room room : availableRooms) {
            if (room.getIsAvailable()) {
                nrOfRooms++;
            }
        }

        System.out.println("\nMultumim pentru ca ati ales " + chosenHotel.getName() + ". Sunt disponibile un numar de " + nrOfRooms + " camere.");

        int reservationID = 1;
        boolean wantAnotherRoom = true;
        while (wantAnotherRoom && nrOfRooms != 0) {
            displayAvailableRoomTypes(chosenHotel);
            System.out.println("\nSelectati un tip de cameră (introduceți numărul): ");
            int roomType = scan.nextInt();
            scan.nextLine();

            double moneySpent = 0;
            boolean roomReserved = reservationSystem.reserveRoom(chosenHotel, roomType, userBudget, moneySpent, reservationID);
            reservationID++;
            if (roomReserved) {
                System.out.print("\nDoriți să rezervați încă o cameră? (da/nu): ");
                String response = scan.nextLine();
                wantAnotherRoom = response.equalsIgnoreCase("da");
            } else {
                System.out.println("\nFonduri insuficiente sau camere indisponibile.");
                wantAnotherRoom = false;
            }
            nrOfRooms--;
        }

        System.out.println("\nDoriți să efectuați check-in-ul la rezervarea făcută? (da/nu): ");
        String checkInResponse = scan.nextLine();

        if (checkInResponse.equalsIgnoreCase("da")) {
            System.out.println("Introduceți numărul rezervării la care doriți să faceți check-in: ");
            int reservationNumber = scan.nextInt();
            scan.nextLine();
            if (reservationSystem.checkIn(reservationNumber)) {
                System.out.println("\nCheck-in efectuat cu succes!");
            } else {
                System.out.println("\nNu s-a putut efectua check-in-ul pentru rezervarea selectată!");
            }
        }

        System.out.println("\nDoriti sa lasati o recenzie acestui hotel? Alegeti intre Y sau N.");
        String userChoice = scan.nextLine();
        if (userChoice.equalsIgnoreCase("Y")) {
            reservationSystem.leaveReview(chosenHotel);
        } else {
            System.out.println("La revedere!");
        }
    }

    public static void displayHotels(List<Hotel> hotels) {
        for (int i = 0; i < hotels.size(); i++) {
            System.out.println((i + 1) + ". " + hotels.get(i).getName());
        }
    }

    public static void displayAvailableRoomTypes(Hotel hotel) {
        Set<Room> roomsDisplayed = new HashSet<>();
        List<Room> availableRooms = hotel.getTypesOfRooms();

        System.out.println("Tipurile de camere disponibile sunt: ");
        for (Room room : availableRooms) {
            if (room.getIsAvailable() && !roomsDisplayed.contains(room)) {
                roomsDisplayed.add(room);

                switch (room.getType()) {
                    case 1:
                        System.out.println("Camera " + room.getRoomNumber() + " pentru o persoana (tip 1). \nPret: " + room.getPrice());
                        break;
                    case 2:
                        System.out.println("Camera " + room.getRoomNumber() + " pentru doua persoane (tip 2). \nPret: " + room.getPrice());
                        break;
                    case 3:
                        System.out.println("Suita " + room.getRoomNumber() + " (tip 3). \nPret: " + room.getPrice());
                        break;
                    case 4:
                        System.out.println("Camera matrimoniala" + room.getRoomNumber() + " (tip 4). \nPret: " + room.getPrice());
                        break;
                    default:
                        System.out.println("Tipul camerei este indisponibil.");
                }
            }
        }
    }
}
