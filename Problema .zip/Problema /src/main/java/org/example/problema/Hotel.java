package org.example.problema;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private int id;
    private String name;
    private double latitude;
    private double longitude;
    private List<Room> rooms;
    private List<String> reviews;

    public Hotel() {
        this.rooms = new ArrayList<>();
        this.reviews = new ArrayList<String>();
    }

    public Hotel(int id, String name, double latitude, double longitude, List<Room> rooms) {
        this.id = id;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.rooms = rooms;
        this.reviews = new ArrayList<String>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public List<Room> getTypesOfRooms() {
        return rooms;
    }

    public void setRooms(List<Room> rooms) {
        this.rooms = rooms;
    }

    public List<String> getReviews() {
        return reviews;
    }

    public void setReviews(List<String> reviews) {
       this.reviews = reviews;
    }

    public double distanceToUser(double userLat, double userLon, double hotelLat, double hotelLon) {
        double R = 6371;

        double lat1 = userLat;
        double long1 = userLon;

        double lat2 = hotelLat;
        double long2 = hotelLon;

        double radLat1 = Math.toRadians(lat1);
        double radLat2 = Math.toRadians(lat2);
        double difLat = Math.toRadians(lat2 - lat1);
        double difLong = Math.toRadians(long2 - long1);

        double a = Math.sin(difLat / 2) * Math.sin(difLat / 2) +
                Math.cos(radLat1) * Math.cos(radLat2) *
                        Math.sin(difLong / 2) * Math.sin(difLong / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        
        return R * c;
    }
}
