package org.example.problema;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.http.HttpServletResponse;
import org.example.problema.Hotel;
import org.example.problema.HotelReservationSystem.*;
import org.example.problema.JsonUtils;

@WebServlet(name = "HotelServlet", value = "/HotelServlet")
public class HotelServlet extends HttpServlet {
    private static List<Hotel> hotels = new ArrayList<>();

    public static List<Hotel> getHotels(){
        return hotels;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        double budget = Double.parseDouble(request.getParameter("budget"));
        double range = Double.parseDouble(request.getParameter("range"));

        hotels = JsonUtils.loadHotels(getServletContext().getRealPath("/WEB-INF/hotels.json"));
        List<Hotel> availableHotels = HotelReservationSystem.getHotelsInRange(range);

        JsonUtils json = new JsonUtils();

        RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/pages/hotels.jsp");
        rd.forward(request,response);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

    }
}