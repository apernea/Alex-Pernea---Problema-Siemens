package org.example.problema;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class JsonUtils {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static List<Hotel> loadHotels(String filePath) throws IOException {
        Objects.requireNonNull(filePath, "File path must not be null");

        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filePath);
        }

        return objectMapper.readValue(file, new TypeReference<List<Hotel>>() {});
    }

    public static void saveHotels(List<Hotel> hotels, String filePath) throws IOException {
        Objects.requireNonNull(filePath, "File path must not be null");
        File file = new File(filePath);

        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filePath);
        }

        try (FileWriter fileWriter = new FileWriter(file)) {
            objectMapper.writeValue(fileWriter, hotels);
        }
    }
}