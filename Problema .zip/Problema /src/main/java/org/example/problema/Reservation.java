package org.example.problema;

import java.time.LocalTime;

public class Reservation {
    private Hotel hotel;
    private Room typeOfRoom;
    private int nrRooms;
    private double totalPrice;
    private LocalTime timeOfReservation;
    private int reservationId;

    public Reservation(Hotel hotel, Room Room, int numberOfRooms, double totalPrice, int reservationId) {
        this.hotel = hotel;
        this.typeOfRoom = Room;
        this.nrRooms = numberOfRooms;
        this.totalPrice = totalPrice;
        this.timeOfReservation = LocalTime.now();
        this.reservationId = reservationId;
    }

    public Hotel getHotel(){
        return hotel;
    }
    public void setHotel(Hotel hotelToSet){
        hotel = hotelToSet;
    }

    public Room getTypeOfRoom(){
        return typeOfRoom;
    }
    public void setTypeOfRoom(Room typeToSet){
        typeOfRoom = typeToSet;
    }

    public int getNumberRooms(){
        return nrRooms;
    }
    public void setNumberRooms(int nrToSet){
        nrRooms = nrToSet;
    }

    public double getTotalPrice(){
        return totalPrice;
    }
    public void setTotalPrice(double priceToSet){
        totalPrice = priceToSet;
    }

    public LocalTime getTimeOfReservation() {
        return timeOfReservation;
    }

    public int getReservationId() {
        return reservationId;
    }
    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }
}
