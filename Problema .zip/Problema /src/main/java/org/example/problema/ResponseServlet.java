package org.example.problema;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.example.problema.HotelServlet.getHotels;

@WebServlet(name = "ResponseServlet", value = "/ResponseServlet")
public class ResponseServlet extends HttpServlet {
    private List<Hotel> hotels = new ArrayList<Hotel>();
    private int hotelIndex;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");


        PrintWriter out = response.getWriter();

        if(!request.getParameter("feedback").isEmpty()){
            hotels.get(hotelIndex).getReviews().add(request.getParameter("feedback"));
        }
        JsonUtils JsonWrite = new JsonUtils();

        JsonWrite.saveHotels(hotels, getServletContext().getRealPath("/WEB-INF/hotels.json"));

        RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/pages/succes.jsp");
        rd.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        JsonUtils JsonWrite = new JsonUtils();
        hotels = getHotels();

        for (hotelIndex = 0; hotelIndex < hotels.size(); hotelIndex++) {
            if (request.getParameter("hotel-name").equals(hotels.get(hotelIndex).getName())) {
                for(int j = 0; j < hotels.get(hotelIndex).getTypesOfRooms().size(); j++){
                    if(Objects.equals(request.getParameter(Integer.toString(hotels.get(hotelIndex).getTypesOfRooms().get(j).getRoomNumber())), "on")){
                        hotels.get(hotelIndex).getTypesOfRooms().get(j).setIsAvailable(false);
                    }
                }
                break;
            }
        }

        RequestDispatcher rd = getServletConfig().getServletContext().getRequestDispatcher("/pages/reviews.jsp");
        rd.forward(request,response);
    }
}