package org.example.problema;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class HotelDataUtil {
    public static List<Hotel> loadHotelsFromJson(String path) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        InputStream inputStream = HotelDataUtil.class.getResourceAsStream(path);
        if (inputStream == null) {
            throw new IOException("File not found: " + path);
        }
        return objectMapper.readValue(inputStream, new TypeReference<List<Hotel>>() {});
    }
}
