package org.example.problema;

import java.awt.desktop.SystemSleepEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HotelReservationSystem {
    private static List<Hotel> hotels = new ArrayList<>();
    private final List<Reservation> reservations = new ArrayList<>();
    private static final List<Double> coordinates;
    private static double USER_LAT;
    private static double USER_LON;
    static {
        try {
            coordinates = GeolocationUtil.getCoordinatesFromIp();
            if(coordinates == null) {
                USER_LAT = 46.7712;
                USER_LON = 23.6236;
            }
            USER_LAT = coordinates.get(0);
            USER_LON = coordinates.get(1);
            System.out.println(USER_LON + " " + USER_LAT);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public HotelReservationSystem(List<Hotel> hotels) {
        this.hotels = hotels;
    }

    public static List<Hotel> getHotelsInRange(double range) {
        List<Hotel> availableHotels = new ArrayList<>();
        for (Hotel hotel : hotels) {
            if (hotel.distanceToUser(USER_LAT, USER_LON, hotel.getLatitude(), hotel.getLongitude()) <= range) {
                availableHotels.add(hotel);
            }
        }
        return availableHotels;
    }

    public boolean cancelReservation(Reservation reservation) {
        boolean removed = reservations.remove(reservation);
        if (removed) {
            reservation.getTypeOfRoom().setIsAvailable(true);
        }
        return removed;
    }

    public boolean changeReservedRoom(Reservation reservation, int newRoomType, double userBudget) {
        Hotel hotel = reservation.getHotel();
        List<Room> availableRooms = hotel.getTypesOfRooms();
        for (Room room : availableRooms) {
            if (room.getType() == newRoomType && room.getIsAvailable()) {
                Room oldRoom = reservation.getTypeOfRoom();
                oldRoom.setIsAvailable(true);
                double roomPrice = room.getPrice();
                double moneySpent = reservation.getTotalPrice();
                if (userBudget >= moneySpent + roomPrice) {
                    reservation.setTypeOfRoom(room);
                    reservation.setTotalPrice(moneySpent + roomPrice);
                    room.setIsAvailable(false);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean reserveRoom(Hotel hotel, int roomType, double userBudget, double moneySpent, int id) {
        List<Room> availableRooms = hotel.getTypesOfRooms();
        int roomsReserved = 0;

        for (Room room : availableRooms) {
            if (room.getType() == roomType && room.getIsAvailable()) {
                double roomPrice = room.getPrice();
                if (userBudget >= moneySpent + roomPrice) {
                    System.out.println("Ati rezervat camera " + room.getRoomNumber() + " de tipul " + room.getType() + ".");
                    moneySpent += roomPrice;
                    room.setIsAvailable(false);

                    Reservation reservation = new Reservation(hotel, room, 1, moneySpent, id);
                    reservations.add(reservation);
                    roomsReserved++;
                    break;
                }
            }
        }

        if (roomsReserved == 1) {
            return true;
        } else {
            System.out.println("Fonduri insuficiente sau camere indisponibile.");
            return false;
        }
    }



    public boolean checkIn(int reservationId) {
        for (Reservation reservation : reservations) {
            if (reservation.getReservationId() == reservationId) {
                System.out.println("Bine ați venit la " + reservation.getHotel().getName() + "!");
                System.out.println("Camera dumneavoastră este: " + reservation.getTypeOfRoom().getRoomNumber());
                return true;
            }
        }
        System.out.println("Nu s-a găsit nicio rezervare cu numărul specificat!");
        return false;
    }

    public void leaveReview(Hotel hotel) {
        System.out.println("Va rugam sa lasati o recenzie pentru " + hotel.getName() + ":");
        String review = new Scanner(System.in).nextLine();
        System.out.println("Multumim pentru recenzie!");

    }
}